def analüüsi_teksti(text):
    # Eemaldame tühikud ja loeme sõnade arvu
    sõnad = text.split()
    sõnade_arv = len(sõnad)
    
    # Eemaldame tühikud ja arvutame tähtede arvu
    tähed_ilma_tühikuteta = len(text.replace(" ", ""))
    
    # Leiame pikima sõna
    pikim_sõna = max(sõnad, key=len)
    
    # Tagastame tulemused
    return f'Sõnu: {sõnade_arv}\nTähti ilma tühikuteta: {tähed_ilma_tühikuteta}\nPikim sõna: "{pikim_sõna}"'

# Kasutaja sisendi saamine
text = input("Sisesta tekst: ")

# Funktsiooni kutsumine ja tulemuse kuvamine
print(analüüsi_teksti(text))

